import Bhagvat from "./Bhagvat"
import Dixeet from "./Dixeet"
import Jaytul from "./Jaytul"
import Me from "./Me"
import Nirav from "./Nirav"
import Rajesh from "./Rajesh"
import Tej from "./Tej"
import Virendr from "./Virendr"





const List = [
    {
        id: 1,
        name: "Bhagvat"
    },
    {
        id: 2,
        name: "Dixeet"
    },
    {
        id: 3,
        name: "Jaytul"
    },
    {
        id: 4,
        name: "Me"
    },
    {
        id: 5,
        name: "Nirav"
    },
    {
        id: 6,
        name: "Rajesh"
    },
    {
        id: 7,
        name: "Tej"
    },
    {
        id: 8,
        name: "Virendr"
    },
]


export default List;