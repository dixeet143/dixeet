
import { TbSunset2 } from "react-icons/tb";
import { WiHumidity } from "react-icons/wi";
import { IoRainy } from "react-icons/io5";
import { FiWind } from "react-icons/fi";
import { LuSunset } from "react-icons/lu";
import { LuSunrise } from "react-icons/lu";
import { IoSunnyOutline } from "react-icons/io5";
import { FaCloudSun } from "react-icons/fa";
import { RiHaze2Line } from "react-icons/ri";
import { BsThreeDotsVertical } from "react-icons/bs";
import { FaCamera } from "react-icons/fa";
import { FaSearch } from "react-icons/fa";
import { IoMdSend } from "react-icons/io";
import { MdKeyboardVoice } from "react-icons/md";
import { MdAdd } from "react-icons/md";
import { FaArrowLeft } from "react-icons/fa6";
import { IoMdPhotos } from "react-icons/io";
import { IoDocumentTextOutline } from "react-icons/io5";
import { IoIosContact } from "react-icons/io";
import { IoLocation } from "react-icons/io5";
import { MdOutlineCancel } from "react-icons/md";
import { FaMessage } from "react-icons/fa6";
import { AiTwotoneInfoCircle } from "react-icons/ai";
import { CiEdit } from "react-icons/ci";
const Icons = { TbSunset2, WiHumidity, IoRainy, FiWind, LuSunset, LuSunrise, IoSunnyOutline, FaCloudSun, RiHaze2Line, BsThreeDotsVertical, FaCamera, FaSearch, IoMdSend, MdKeyboardVoice, MdAdd, FaArrowLeft, IoMdPhotos, IoDocumentTextOutline, IoIosContact, IoLocation, MdOutlineCancel, FaMessage, AiTwotoneInfoCircle, CiEdit }



export default Icons
